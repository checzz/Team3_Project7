/****************************************************************************************************/
/**
\file       J2716.h
\brief      J2716 Data types
\author     Team 3
\version    1.0
\date       27/Nov/2012
*/
/****************************************************************************************************/
#ifndef __J2716_TYPES_H        /*prevent duplicated includes*/
#define __J2716_TYPES_H

/*****************************************************************************************************
* Include files
*****************************************************************************************************/

/** Core Modules */
/** Configuration Options */
#include    "configuration.h"
/** S12X derivative information */
#include    __MCU_DERIVATIVE
/** Variable types and common definitions */
#include    "typedefs.h"

/*****************************************************************************************************
* Declaration of module wide TYPES
*****************************************************************************************************/
typedef uint8 J2716_ChannelType;

/* J2716 channels's state */
typedef enum
{
  J2716_INIT=0,
  J2716_IDLE,
  J2716_TX
}J2716_StateType;

/* Supported channles */
typedef enum
{
  J2716_Ch0=0,
  J2716_Ch1,
  J2716_Ch2,
  J2716_Ch3,
  J2716_Ch4,
  J2716_Ch5,
  J2716_Ch6,
  J2716_Ch7,
  J2716_MAX_CHANNELS
}J2716_Channels;

typedef struct
{
  J2716_Channels  enId;
  J2716_StateType enStatus;
  uint8           *DataBuffer;
  uint8           u8Crc;
  uint8           u8CbkEnable;
}J2716_StatusType;

typedef enum
{
  J2716_Start=0,
  J2716_LowPulse,
  J2716_HighPulse,
  J2716_Sync,
  J2716_Status,
  J2716_Data,
  J2716_Crc,
  J2716_Pause,
  J2716_TxBits,
  J2716_Error
}J2716_Sequence;
/*****************************************************************************************************
* Definition of  VARIABLEs - 
*****************************************************************************************************/

#pragma DATA_SEG SHARED_DATA

#pragma DATA_SEG DEFAULT

#pragma DATA_SEG XGATE_DATA

#pragma DATA_SEG DEFAULT	

/*****************************************************************************************************
* Definition of module wide MACROS / #DEFINE-CONSTANTS 
*****************************************************************************************************/

/* Values to define the waveform */
#define J2716_LOW_PULSE_TICKS             ((uint8)5)
#define J2716_MIN_PERIOD_TICKS            ((uint8)12)
#define J2716_SYNC_PERIOD_TICKS           ((uint8)56)
#define J2716_PAUSE_TICKS                 ((uint8)77)

/* Values which define the period in HIGH level on each part of the frame */
#define J2716_MIN_HIGH_PERIOD_TICKS       (J2716_MIN_PERIOD_TICKS - J2716_LOW_PULSE_TICKS)
#define J2716_MIN_HIGH_SYNC_PERIOD_TICKS  (J2716_SYNC_PERIOD_TICKS - J2716_LOW_PULSE_TICKS)
#define J2716_MIN_HIGH_PAUSE_PERIOD_TICKS (J2716_PAUSE_TICKS - J2716_LOW_PULSE_TICKS)

/*****************************************************************************************************
* Declaration of module wide FUNCTIONS
*****************************************************************************************************/

#endif /* __J2716_TYPES_H */