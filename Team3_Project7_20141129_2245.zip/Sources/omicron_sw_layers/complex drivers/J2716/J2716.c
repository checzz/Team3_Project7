/****************************************************************************************************/
/**
\file       J2716.c
\brief      J2716(SENT) initialization and low-level functions and prototypes
\author     Team 3
\version    1.0
\date       27/11/2012
*/
/****************************************************************************************************/

/*****************************************************************************************************
* Include files
*****************************************************************************************************/
/** Own headers */
/* Periodic Interrupt Timer routines prototypes */
#include    "J2716.h"

#include "pit.h"
#include "xgate_config.h"
/*****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/

/*****************************************************************************************************
* Declaration of module wide FUNCTIONs 
*****************************************************************************************************/	

/*****************************************************************************************************
* Definition of module wide MACROs / #DEFINE-CONSTANTs 
*****************************************************************************************************/

/*****************************************************************************************************
* Definition of module wide VARIABLEs 
*****************************************************************************************************/
static  J2716_StatusType  J2716_astChannelStatus[1];
/*****************************************************************************************************
* Definition of module wide (CONST-) CONSTANTs 
*****************************************************************************************************/

/*****************************************************************************************************
* Code of module wide FUNCTIONS
*****************************************************************************************************/

/****************************************************************************************************/
/**
* \brief    J2716 - Initialization
* \author   Team 3
* \param    J2716_ConfigType * kstConfig - Static configuration of the driver
* \return   void
*/
void J2716_Init(const J2716_ConfigType * kstConfig)
{
  uint8 u8Devices=0;
  uint8 u8Channels=0;
  uint8 u8Temp;

  for( u8Devices=0 ; (u8Devices < J2716_u8Devices) ; u8Devices++)
  {
    for( u8Channels=0 ; (u8Channels < kstConfig->u8Channels) ; u8Channels++)
    {
        u8Temp++;
    }
  }  
  
  /* Access to configuration data registers for interrupts */ 
  INT_CFADDR          = 0x70;         /* with vectors from 0xFF70 to 0xFF7E */
  INT_CFDATA0_PRIOLVL = 6;            /* XGATE software trigger 1, priority 6 */
  INT_CFDATA0_RQST    = 1;            /* routed to XGATE */
  /* "SOFTWARE_TRIGGER_2"  == "Channel 38 - XGATE Software Trigger 1" in xgate_vectors.cxgate */
  XGATE_SW_TRIGGER( SOFTWARE_TRIGGER_2, SOFTWARE_TRIGGER_ENABLE);
  /* ToDo: Wait unitl XGATE-PWM is ready  */
  vfnPIT2_Start(); 
}

/****************************************************************************************************/
/**
* \brief    J2716 - De-Initialization
* \author   Team 3
* \param    void
* \return   void
*/
void J2716_DeInit(void)
{
}

/****************************************************************************************************/
/**
* \brief    J2716 - Transmission of data
* \author   Team 3
* \param    uint8 * pu8DataBuffer - Address of the buffer where the data will be taken from
* \return   Std_ReturnType
*/
Std_ReturnType J2716_Transmit(uint8 * pu8DataBuffer)
{
return E_OK;
}

/****************************************************************************************************/
/**
* \brief    J2716 - De-Initialization
* \author   Team 3
* \param    J2716_ChannelType xChannel  - Channel where the notification will be enabled
* \return   void
*/
void J2716_EnableNotification(J2716_ChannelType xChannel)
{
}

/****************************************************************************************************/
/**
* \brief    J2716 - De-Initialization
* \author   Team 3
* \param    J2716_ChannelType xChannel  - Channel where the notification will be disabled
* \return   void
*/
void J2716_DisableNotification(J2716_ChannelType xChannel)
{
}