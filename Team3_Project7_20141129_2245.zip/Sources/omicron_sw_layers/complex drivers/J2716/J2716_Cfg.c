/****************************************************************************************************/
/**
\file       J2716_Cfg.c
\brief      J2716 static configuration structure
\author     Team 3
\version    1.0
\date       27/Nov/2012
*/
/****************************************************************************************************/
#include "J2716_Cfg.h"

/* Channel(s) configuration */
const J2716_ConfigChannelType  J2716_astChannelsCfg[]=
{
/*  CHANNEL PORT  PIN LENGHT  TICK(us)  PAUSE NOTIFICATION  */
{J2716_Ch0, NULL,  D0,     6,        3,  TRUE, NULL},
{J2716_Ch1, NULL,  D1,     6,        3,  TRUE, NULL}
};

/* Device(s) configuration */
const J2716_ConfigType  J2716_astDevicesCfg[]=
{
{0/*Device ID*/,(sizeof(J2716_astChannelsCfg)/sizeof(J2716_ConfigChannelType)),&J2716_astChannelsCfg[0]}
};

/* Devices configurated */
const uint8 J2716_u8Devices = (uint8)(sizeof(J2716_astDevicesCfg)/sizeof(J2716_ConfigType));