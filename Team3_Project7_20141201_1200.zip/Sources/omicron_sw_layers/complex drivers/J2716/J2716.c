/****************************************************************************************************/
/**
\file       J2716.c
\brief      J2716(SENT) initialization and low-level functions and prototypes
\author     Team 3
\version    1.0
\date       27/11/2012
*/
/****************************************************************************************************/

/*****************************************************************************************************
* Include files
*****************************************************************************************************/
/** Own headers */
/* Periodic Interrupt Timer routines prototypes */
#include "J2716.h"

#include "pit.h"
#include "xgate_config.h"
#include "memory_allocation.h"
/*****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/

/*****************************************************************************************************
* Declaration of module wide FUNCTIONs 
*****************************************************************************************************/	

/*****************************************************************************************************
* Definition of module wide MACROs / #DEFINE-CONSTANTs 
*****************************************************************************************************/

/*****************************************************************************************************
* Definition of module wide VARIABLEs 
*****************************************************************************************************/
#pragma DATA_SEG SHARED_DATA
extern volatile J2716_StatusType * pstChannelsStat;
#pragma DATA_SEG DEFAULT
/*****************************************************************************************************
* Definition of module wide (CONST-) CONSTANTs 
*****************************************************************************************************/

/*****************************************************************************************************
* Code of module wide FUNCTIONS
*****************************************************************************************************/

/****************************************************************************************************/
/**
* \brief    J2716 - Initialization
* \author   Team 3
* \param    J2716_ConfigType * kstConfig - Static configuration of the driver
* \return   void
*/
void J2716_Init(const J2716_ConfigType * kstConfig)
{
  uint8 u8Devices=0;
  uint8 u8Channel=0;
  uint8 u8Temp=0;

  /* Get total number of channels */
  for( u8Devices=0 ; (u8Devices < J2716_u8Devices) ; u8Devices++)
  {
    u8Temp+=kstConfig[u8Devices].u8Channels;
  }
  pstChannelsStat = (J2716_StatusType*)MemAlloc_NearReserve(sizeof(J2716_StatusType)*u8Temp);  
  
  for( u8Devices=0 ; (u8Devices < J2716_u8Devices) ; u8Devices++)
  {
    for( u8Channel=0 ; (u8Channel < kstConfig->u8Channels) ; u8Channel++)
    {
       /* ToDo: initialize here the channels */
       pstChannelsStat[u8Channel].enMsgStatus     = J2716_INIT;
       pstChannelsStat[u8Channel].enId            = ((J2716_ConfigChannelType*)kstConfig[u8Devices].pstChannlesCfg)[u8Channel].enId;
       pstChannelsStat[u8Channel].pu16MsgPort     = ((J2716_ConfigChannelType*)kstConfig[u8Devices].pstChannlesCfg)[u8Channel].pu16OutputPort;
       pstChannelsStat[u8Channel].pu8MsgData      = (uint8*)0x1234;
       pstChannelsStat[u8Channel].u8MsgPin        = ((J2716_ConfigChannelType*)kstConfig[u8Devices].pstChannlesCfg)[u8Channel].u8PortPin;
       pstChannelsStat[u8Channel].u8MsgTick       = ((J2716_ConfigChannelType*)kstConfig[u8Devices].pstChannlesCfg)[u8Channel].u8TickPeriod;
       pstChannelsStat[u8Channel].u8MsgLen        = ((J2716_ConfigChannelType*)kstConfig[u8Devices].pstChannlesCfg)[u8Channel].u8MsgLen;
       pstChannelsStat[u8Channel].u8MsgCrc        = 0x55;
       if(((J2716_ConfigChannelType*)kstConfig[u8Devices].pstChannlesCfg)[u8Channel].pfnCallback!=NULL)
       pstChannelsStat[u8Channel].u8MsgCbkEn      = TRUE;
       else
       pstChannelsStat[u8Channel].u8MsgCbkEn      = 0xFF;
       
    }
  }
  
  /* Access to configuration data registers for interrupts */ 
  INT_CFADDR          = 0x70;         /* with vectors from 0xFF70 to 0xFF7E */
  INT_CFDATA0_PRIOLVL = 6;            /* XGATE software trigger 1, priority 6 */
  INT_CFDATA0_RQST    = 1;            /* routed to XGATE */
  /* "SOFTWARE_TRIGGER_2"  == "Channel 38 - XGATE Software Trigger 1" in xgate_vectors.cxgate */
  XGATE_SW_TRIGGER( SOFTWARE_TRIGGER_2, SOFTWARE_TRIGGER_ENABLE);
  /* PIT Ch2 will be started unitl XGATE-J2716 Init is ready "XGATE Software Trigger 2"  */ 
}

/****************************************************************************************************/
/**
* \brief    J2716 - De-Initialization
* \author   Team 3
* \param    void
* \return   void
*/
void J2716_DeInit(void)
{
}

/****************************************************************************************************/
/**
* \brief    J2716 - Transmission of data
* \author   Team 3
* \param    uint8 * pu8DataBuffer - Address of the buffer where the data will be taken from
* \return   Std_ReturnType
*/
Std_ReturnType J2716_Transmit(J2716_ChannelType xChannel, uint8 * pu8DataBuffer)
{
return E_OK;
}

/****************************************************************************************************/
/**
* \brief    J2716 - De-Initialization
* \author   Team 3
* \param    J2716_ChannelType xChannel  - Channel where the notification will be enabled
* \return   void
*/
void J2716_EnableNotification(J2716_ChannelType xChannel)
{
  pstChannelsStat[xChannel].u8MsgCbkEn      = TRUE;
}

/****************************************************************************************************/
/**
* \brief    J2716 - De-Initialization
* \author   Team 3
* \param    J2716_ChannelType xChannel  - Channel where the notification will be disabled
* \return   void
*/
void J2716_DisableNotification(J2716_ChannelType xChannel)
{
  pstChannelsStat[xChannel].u8MsgCbkEn      = 0xFF;
}

/****************************************************************************************************/
/**
* \brief    J2716 Init ISR, if reached, XGATE has initialized PIT ("XGATE Software Trigger 2")
* \author   Team 3
* \param    void
* \return   void
*/
#pragma CODE_SEG __NEAR_SEG NON_BANKED
void interrupt  vfnJ2716_InitX_Isr( void  )
{
  /* Clear Software Interrupt request flag */
  XGATE_SW_TRIGGER( SOFTWARE_TRIGGER_3, SOFTWARE_TRIGGER_DISABLE);
  vfnPIT2_Start();
}
#pragma CODE_SEG DEFAULT