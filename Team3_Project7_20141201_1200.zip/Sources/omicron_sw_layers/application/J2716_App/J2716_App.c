/****************************************************************************************************/
/**
\file       J2716.cxgate
\brief      SW PWM signal generation functions for the XGATE
\author     Team 3
\version    1.0
\date       30/10/2014
*/
/****************************************************************************************************/

/*****************************************************************************************************
* Include files
*****************************************************************************************************/
/** Core modules */
#include "J2716_App.h"
/** driver types Configuration Options */

/** prototypes and main header Configuration Options */

/** frecuency values */
#include "pll.h"
#include "xgate_config.h"
#include "pit.h"
#include "gpio.h"
/*****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/
static uint8 J2716__u8Counter=0;
/*****************************************************************************************************
* Declaration of module wide FUNCTIONs 
*****************************************************************************************************/

/*****************************************************************************************************
* Definition of module wide MACROs / #DEFINE-CONSTANTs 
*****************************************************************************************************/
#define J2716_APP_CLR_LOW_NIBBLE    ((uint8)0xF0)
#define J2716_APP_LOW_NIBBLE_MSK    ((uint8)0x0F)
/*****************************************************************************************************
* Definition of module wide VARIABLEs 
*****************************************************************************************************/
void J2716_100ms(void)
{
  uint8 u8TempPort;
  
  u8TempPort = PORTA;                         /* Read PORTA curernt value */
  u8TempPort&=J2716_APP_CLR_LOW_NIBBLE;       /* Clear low nibble*/
  u8TempPort|=J2716__u8Counter;               /* Append counter value*/
  PORTA = u8TempPort;                         /* Display value on LEDs (PA0...PA3) */
  
  J2716__u8Counter++;
  J2716__u8Counter&=J2716_APP_LOW_NIBBLE_MSK; /* Mask low nibble (0-15 values allowed) */
}