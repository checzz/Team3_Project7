/****************************************************************************************************/
/**
\file       J2716.cxgate
\brief      SW PWM signal generation functions for the XGATE
\author     Team 3
\version    1.0
\date       30/10/2014
*/
/****************************************************************************************************/

/*****************************************************************************************************
* Include files
*****************************************************************************************************/
/** Core modules */
#include "J2716_App.h"
/** driver types Configuration Options */

/** prototypes and main header Configuration Options */

/** frecuency values */
#include "pll.h"
#include "xgate_config.h"
#include "pit.h"
#include "gpio.h"
/*****************************************************************************************************
* Declaration of module wide TYPEs 
*****************************************************************************************************/
static uint8 J2716__u8Counter=0;
static uint8 J2716_App[6];
/*****************************************************************************************************
* Declaration of module wide FUNCTIONs 
*****************************************************************************************************/

/*****************************************************************************************************
* Definition of module wide MACROs / #DEFINE-CONSTANTs 
*****************************************************************************************************/
#define J2716_APP_CLR_LOW_NIBBLE    ((uint8)0xFC)
#define J2716_APP_LOW_NIBBLE_MSK    ((uint8)0x03)
/*****************************************************************************************************
* Definition of module wide VARIABLEs 
*****************************************************************************************************/
void J2716_100ms(void)
{
  uint8 u8TempPort;
  
  u8TempPort = PORTA;                         /* Read PORTA curernt value */
  u8TempPort&= J2716_APP_CLR_LOW_NIBBLE;       /* Clear low nibble*/
  u8TempPort|= J2716__u8Counter;               /* Append counter value*/
  PORTA = u8TempPort;                         /* Display value on LEDs (PA0...PA3) */
  
  J2716__u8Counter++;
  J2716__u8Counter&=J2716_APP_LOW_NIBBLE_MSK; /* Mask low nibble (0-15 values allowed) */
  J2716_App[0]=15;
  J2716_App[1]=14;
  J2716_App[2]=13;
  J2716_App[3]=12;
  J2716_App[4]=11;
  J2716_App[5]=10;
  J2716_Transmit(0,&J2716_App[0]);
  J2716_Transmit(1,&J2716_App[3]);
}

void J2716_Cbk0(void)
{
  PORT_TOGGLE(PORTA,PORTA_PA2_MASK);
}

void J2716_Cbk1(void)
{
  PORT_TOGGLE(PORTA,PORTA_PA3_MASK);
}