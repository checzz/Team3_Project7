/****************************************************************************************************/
/**
\file       J2716.h
\brief      J2716 Data types
\author     Team 3
\version    1.0
\date       27/Nov/2012
*/
/****************************************************************************************************/
#ifndef __J2716_TYPES_H        /*prevent duplicated includes*/
#define __J2716_TYPES_H

/*****************************************************************************************************
* Include files
*****************************************************************************************************/

/** Core Modules */
/** Configuration Options */
#include    "configuration.h"
/** S12X derivative information */
#include    __MCU_DERIVATIVE
/** Variable types and common definitions */
#include    "typedefs.h"

/*****************************************************************************************************
* Declaration of module wide TYPES
*****************************************************************************************************/
typedef uint8 J2716_ChannelType;

/* J2716 channels's state */
typedef enum
{
  J2716_INIT=0,
  J2716_IDLE,
  J2716_TX
}J2716_StateType;

/* Supported channles */
typedef enum
{
  J2716_Ch0=0,
  J2716_Ch1,
  J2716_Ch2,
  J2716_Ch3,
  J2716_Ch4,
  J2716_Ch5,
  J2716_Ch6,
  J2716_Ch7,
  J2716_MAX_CHANNELS
}J2716_Channels;

typedef struct
{
  J2716_Channels  enId;
  J2716_StateType enStatus;
  uint8           *DataBuffer;
  uint8           u8Crc;
}J2716_StatusType;
/*****************************************************************************************************
* Definition of  VARIABLEs - 
*****************************************************************************************************/

#pragma DATA_SEG SHARED_DATA

#pragma DATA_SEG DEFAULT

#pragma DATA_SEG XGATE_DATA

#pragma DATA_SEG DEFAULT	

/*****************************************************************************************************
* Definition of module wide MACROS / #DEFINE-CONSTANTS 
*****************************************************************************************************/

/*****************************************************************************************************
* Declaration of module wide FUNCTIONS
*****************************************************************************************************/

#endif /* __J2716_TYPES_H */